package io.springgeeks.duka.service;

import io.springgeeks.duka.domain.SystemUser;

public interface SystemUserService {
   public SystemUser addNewSystemUser(SystemUser systemUser);
}
