package io.springgeeks.duka.domain;

public enum Activity {
    Selling, Renting
}
