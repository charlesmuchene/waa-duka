# Duka: Borrow or Bid
Spring-backed online shop that allows you to borrow or buy (via bidding) product.
## Contributors
* Idelphonse
* Robert
* Honoré
* Josue
* Charles